#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  DreamBooth + DoRA Studio — installer & launcher
#  Usage:  bash run.sh
# ─────────────────────────────────────────────────────────────
set -e

PYTHON=${PYTHON:-python3}
VENV_DIR=".venv"

echo ""
echo "  ██████╗ ██████╗ ███████╗ █████╗ ███╗   ███╗"
echo "  ██╔══██╗██╔══██╗██╔════╝██╔══██╗████╗ ████║"
echo "  ██║  ██║██████╔╝█████╗  ███████║██╔████╔██║"
echo "  ██║  ██║██╔══██╗██╔══╝  ██╔══██║██║╚██╔╝██║"
echo "  ██████╔╝██║  ██║███████╗██║  ██║██║ ╚═╝ ██║"
echo "  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝"
echo ""
echo "  DreamBooth + DoRA Studio"
echo "  Weight-Decomposed Adaptation for Stable Diffusion"
echo ""

# ── Check Python ────────────────────────────────────────────
if ! command -v $PYTHON &>/dev/null; then
  echo "ERROR: Python 3 not found. Install Python 3.10+ and retry."
  exit 1
fi

PY_VERSION=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "  Python $PY_VERSION found"

# ── Create/reuse virtualenv ──────────────────────────────────
if [ ! -d "$VENV_DIR" ]; then
  echo "  Creating virtual environment…"
  $PYTHON -m venv $VENV_DIR
fi
source $VENV_DIR/bin/activate

# ── Install/upgrade deps ─────────────────────────────────────
echo "  Installing dependencies…"
pip install --upgrade pip -q

# Detect CUDA
if python -c "import torch; assert torch.cuda.is_available()" 2>/dev/null; then
  echo "  CUDA detected — keeping existing PyTorch"
else
  echo "  No CUDA detected — installing CPU PyTorch"
  pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu -q
fi

pip install -r requirements.txt -q
echo "  Dependencies installed ✓"

# ── Create necessary directories ─────────────────────────────
mkdir -p uploads outputs checkpoints

# ── Launch ────────────────────────────────────────────────────
echo ""
echo "  ┌──────────────────────────────────────────────┐"
echo "  │  Starting server at http://localhost:8000     │"
echo "  │  Press Ctrl+C to stop                        │"
echo "  └──────────────────────────────────────────────┘"
echo ""
python app.py
