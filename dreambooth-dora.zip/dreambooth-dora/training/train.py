"""
training/train.py
─────────────────
DreamBooth fine-tuning with DoRA (Weight-Decomposed Low-Rank Adaptation).

DoRA replaces LoRA by decomposing each weight update into:
  - a magnitude vector  m  (learned scalar norms)
  - a direction matrix  V  (low-rank, identical structure to LoRA)

  W' = m · (W₀ + ΔW) / ‖W₀ + ΔW‖

This gives strictly better expressiveness than LoRA at the same parameter budget.

Usage
-----
    python training/train.py \
        --session_id=abc123 \
        --instance_prompt="a photo of [V] person" \
        --class_prompt="a photo of a person" \
        --model_base="runwayml/stable-diffusion-v1-5" \
        --max_train_steps=1000 \
        --dora_rank=32 \
        --dora_alpha=32 \
        --output_dir=checkpoints/myjob
"""

import argparse, json, math, os, shutil, logging
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

from diffusers import (
    AutoencoderKL,
    DDPMScheduler,
    StableDiffusionPipeline,
    UNet2DConditionModel,
)
from diffusers.optimization import get_scheduler
from transformers import CLIPTextModel, CLIPTokenizer

# DoRA via PEFT ─────────────────────────────────────────────
from peft import LoraConfig, get_peft_model

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════
#  Dataset
# ═══════════════════════════════════════════════════════════

class DreamBoothDataset(Dataset):
    """
    Loads instance images (subject) + optionally class images (prior preservation).
    All images are resized to `resolution × resolution`.
    """

    def __init__(
        self,
        instance_data_dir: str,
        instance_prompt: str,
        tokenizer: CLIPTokenizer,
        class_data_dir: str = None,
        class_prompt: str = None,
        resolution: int = 512,
        with_prior_preservation: bool = True,
    ):
        self.tokenizer = tokenizer
        self.resolution = resolution
        self.with_prior = with_prior_preservation

        self.instance_images = sorted(
            [p for p in Path(instance_data_dir).iterdir()
             if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}]
        )
        self.instance_prompt = instance_prompt
        log.info(f"Found {len(self.instance_images)} instance images")

        self.class_images = []
        if with_prior_preservation and class_data_dir:
            self.class_images = sorted(
                [p for p in Path(class_data_dir).iterdir()
                 if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}]
            )
            self.class_prompt = class_prompt
            log.info(f"Found {len(self.class_images)} class images (prior preservation)")

        self.transform = transforms.Compose([
            transforms.Resize(resolution, interpolation=transforms.InterpolationMode.BILINEAR),
            transforms.CenterCrop(resolution),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5]),
        ])

    def __len__(self):
        return max(len(self.instance_images),
                   len(self.class_images) if self.with_prior else 0) * 2 \
               if self.with_prior and self.class_images \
               else len(self.instance_images)

    def __getitem__(self, idx):
        example = {}

        # Instance image
        inst_idx = idx % len(self.instance_images)
        img = Image.open(self.instance_images[inst_idx]).convert("RGB")
        example["instance_images"] = self.transform(img)
        example["instance_prompt_ids"] = self.tokenizer(
            self.instance_prompt,
            padding="do_not_pad",
            truncation=True,
            max_length=self.tokenizer.model_max_length,
        ).input_ids

        # Class image (prior preservation)
        if self.with_prior and self.class_images:
            cls_idx = idx % len(self.class_images)
            cls_img = Image.open(self.class_images[cls_idx]).convert("RGB")
            example["class_images"] = self.transform(cls_img)
            example["class_prompt_ids"] = self.tokenizer(
                self.class_prompt,
                padding="do_not_pad",
                truncation=True,
                max_length=self.tokenizer.model_max_length,
            ).input_ids

        return example


def collate_fn(examples, with_prior: bool, tokenizer: CLIPTokenizer):
    input_ids = [e["instance_prompt_ids"] for e in examples]
    pixel_values = [e["instance_images"] for e in examples]

    if with_prior:
        input_ids += [e["class_prompt_ids"] for e in examples]
        pixel_values += [e["class_images"] for e in examples]

    pixel_values = torch.stack(pixel_values).float()
    input_ids = tokenizer.pad(
        {"input_ids": input_ids},
        padding=True,
        return_tensors="pt",
    ).input_ids
    return {"pixel_values": pixel_values, "input_ids": input_ids}


# ═══════════════════════════════════════════════════════════
#  DoRA model builder
# ═══════════════════════════════════════════════════════════

def build_dora_unet(unet: UNet2DConditionModel, rank: int, alpha: int, target_modules: list[str]):
    """
    Wraps the UNet with DoRA via PEFT's LoraConfig(use_dora=True).

    DoRA decomposes every adapted weight matrix W into:
        W = m · (W₀ + AB) / ‖W₀ + AB‖₂
    where:
        A ∈ ℝ^{d × r}  (down projection, init ~ N(0, σ))
        B ∈ ℝ^{r × k}  (up projection,   init = 0)
        m ∈ ℝ^d        (magnitude vector, init = ‖W₀‖₂ per row)
    """
    config = LoraConfig(
        r=rank,
        lora_alpha=alpha,
        target_modules=target_modules,
        lora_dropout=0.05,
        use_dora=True,       # ← this single flag enables DoRA instead of LoRA
        bias="none",
    )
    unet = get_peft_model(unet, config)
    unet.print_trainable_parameters()
    return unet


# ═══════════════════════════════════════════════════════════
#  Prior image generation
# ═══════════════════════════════════════════════════════════

def generate_prior_images(
    model_base: str,
    class_prompt: str,
    output_dir: Path,
    num_images: int = 100,
    device: str = "cuda",
):
    """Generate class images for prior preservation loss."""
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = list(output_dir.glob("*.png"))
    if len(existing) >= num_images:
        log.info(f"Prior images already exist ({len(existing)}), skipping generation")
        return

    log.info(f"Generating {num_images} prior images with prompt: '{class_prompt}'")
    pipeline = StableDiffusionPipeline.from_pretrained(
        model_base, torch_dtype=torch.float16, safety_checker=None
    ).to(device)

    for i in range(0, num_images, 4):
        batch = min(4, num_images - i)
        images = pipeline(
            [class_prompt] * batch,
            num_inference_steps=25,
            guidance_scale=7.0,
        ).images
        for j, img in enumerate(images):
            img.save(output_dir / f"class_{i+j:04d}.png")

    del pipeline
    torch.cuda.empty_cache()
    log.info("Prior image generation complete")


# ═══════════════════════════════════════════════════════════
#  Main training loop
# ═══════════════════════════════════════════════════════════

def train(args):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype  = torch.float16 if args.mixed_precision == "fp16" else torch.float32
    log.info(f"Device: {device} | dtype: {dtype}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Load tokenizer & text encoder ───────────────────
    log.info(f"Loading model: {args.model_base}")
    tokenizer = CLIPTokenizer.from_pretrained(args.model_base, subfolder="tokenizer")
    text_encoder = CLIPTextModel.from_pretrained(
        args.model_base, subfolder="text_encoder"
    ).to(device, dtype=dtype)

    # ── Load VAE & noise scheduler ───────────────────────
    vae = AutoencoderKL.from_pretrained(
        args.model_base, subfolder="vae"
    ).to(device, dtype=dtype)
    noise_scheduler = DDPMScheduler.from_pretrained(
        args.model_base, subfolder="scheduler"
    )

    # ── Load UNet and wrap with DoRA ─────────────────────
    unet = UNet2DConditionModel.from_pretrained(
        args.model_base, subfolder="unet"
    ).to(device, dtype=dtype)

    target_modules = [m.strip() for m in args.dora_target_modules.split(",")]
    log.info(f"Applying DoRA to modules: {target_modules}")
    unet = build_dora_unet(unet, args.dora_rank, args.dora_alpha, target_modules)

    # Freeze everything except DoRA params
    vae.requires_grad_(False)
    text_encoder.requires_grad_(False)

    # ── Prior preservation images ────────────────────────
    class_data_dir = None
    if args.with_prior_preservation:
        class_data_dir = output_dir / "class_images"
        generate_prior_images(
            args.model_base, args.class_prompt,
            class_data_dir, args.num_class_images, device,
        )

    # ── Dataset & dataloader ─────────────────────────────
    instance_dir = Path("uploads") / args.session_id
    dataset = DreamBoothDataset(
        instance_data_dir=str(instance_dir),
        instance_prompt=args.instance_prompt,
        tokenizer=tokenizer,
        class_data_dir=str(class_data_dir) if class_data_dir else None,
        class_prompt=args.class_prompt,
        resolution=512,
        with_prior_preservation=args.with_prior_preservation,
    )

    dataloader = DataLoader(
        dataset,
        batch_size=args.train_batch_size,
        shuffle=True,
        collate_fn=lambda b: collate_fn(b, args.with_prior_preservation, tokenizer),
        num_workers=0,
    )

    # ── Optimizer (only DoRA params) ─────────────────────
    dora_params = [p for p in unet.parameters() if p.requires_grad]
    log.info(f"Trainable DoRA parameters: {sum(p.numel() for p in dora_params):,}")

    try:
        import bitsandbytes as bnb
        optimizer = bnb.optim.AdamW8bit(dora_params, lr=args.learning_rate)
        log.info("Using AdamW-8bit optimizer")
    except ImportError:
        optimizer = torch.optim.AdamW(dora_params, lr=args.learning_rate)
        log.info("Using standard AdamW optimizer (install bitsandbytes for 8-bit)")

    lr_scheduler = get_scheduler(
        "cosine",
        optimizer=optimizer,
        num_warmup_steps=min(100, args.max_train_steps // 10),
        num_training_steps=args.max_train_steps,
    )

    # ── Training loop ────────────────────────────────────
    unet.train()
    global_step = 0
    log.info(f"Starting training for {args.max_train_steps} steps")

    while global_step < args.max_train_steps:
        for batch in dataloader:
            if global_step >= args.max_train_steps:
                break

            pixel_values = batch["pixel_values"].to(device, dtype=dtype)
            input_ids    = batch["input_ids"].to(device)

            # Encode images to latent space
            latents = vae.encode(pixel_values).latent_dist.sample() * vae.config.scaling_factor

            # Sample noise
            noise     = torch.randn_like(latents)
            timesteps = torch.randint(0, noise_scheduler.config.num_train_timesteps,
                                      (latents.shape[0],), device=device).long()
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            # Text conditioning
            encoder_hidden = text_encoder(input_ids)[0]

            # Predict noise
            noise_pred = unet(noisy_latents, timesteps, encoder_hidden).sample

            # Split instance / class
            if args.with_prior_preservation:
                half = noise_pred.shape[0] // 2
                noise_pred_inst, noise_pred_cls = noise_pred[:half], noise_pred[half:]
                noise_inst, noise_cls           = noise[:half],      noise[half:]
                instance_loss = F.mse_loss(noise_pred_inst, noise_inst, reduction="mean")
                prior_loss    = F.mse_loss(noise_pred_cls,  noise_cls,  reduction="mean")
                loss = instance_loss + args.prior_loss_weight * prior_loss
            else:
                loss = F.mse_loss(noise_pred, noise, reduction="mean")

            loss.backward()
            torch.nn.utils.clip_grad_norm_(dora_params, 1.0)
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

            global_step += 1
            if global_step % 50 == 0:
                log.info(f"step={global_step}/{args.max_train_steps}  "
                         f"loss={loss.item():.4f}  "
                         f"lr={lr_scheduler.get_last_lr()[0]:.2e}")

    # ── Save checkpoint ───────────────────────────────────
    log.info(f"Saving DoRA checkpoint to {output_dir}")
    unet.save_pretrained(str(output_dir / "unet_dora"))

    # Save training config
    config = vars(args)
    config["device"] = device
    with open(output_dir / "training_config.json", "w") as f:
        json.dump(config, f, indent=2)

    log.info("✓ Training complete")


# ═══════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════

def parse_args():
    p = argparse.ArgumentParser(description="DreamBooth + DoRA trainer")
    p.add_argument("--session_id",            required=True)
    p.add_argument("--instance_prompt",       required=True)
    p.add_argument("--class_prompt",          required=True)
    p.add_argument("--unique_token",          default="[V]")
    p.add_argument("--model_base",            default="runwayml/stable-diffusion-v1-5")
    p.add_argument("--output_dir",            default="checkpoints/run")
    p.add_argument("--job_id",                default="")
    # Training
    p.add_argument("--max_train_steps",       type=int,   default=1000)
    p.add_argument("--learning_rate",         type=float, default=2e-6)
    p.add_argument("--train_batch_size",      type=int,   default=1)
    p.add_argument("--gradient_accumulation_steps", type=int, default=4)
    p.add_argument("--prior_loss_weight",     type=float, default=1.0)
    p.add_argument("--num_class_images",      type=int,   default=100)
    p.add_argument("--with_prior_preservation", action="store_true", default=True)
    # DoRA
    p.add_argument("--dora_rank",             type=int,   default=32)
    p.add_argument("--dora_alpha",            type=int,   default=32)
    p.add_argument("--dora_lambda",           type=float, default=0.8)
    p.add_argument("--dora_target_modules",   default="q,k,v,out")
    # Misc
    p.add_argument("--mixed_precision",       default="fp16")
    return p.parse_args()


if __name__ == "__main__":
    train(parse_args())
