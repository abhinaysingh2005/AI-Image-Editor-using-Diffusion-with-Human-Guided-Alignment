# DreamBooth · DoRA Studio

> Fine-tune Stable Diffusion on your own subject images using **DreamBooth** personalization
> with **DoRA** (Weight-Decomposed Low-Rank Adaptation) as the adapter — achieving better
> fidelity than LoRA at the same parameter count.

---

## What is DoRA?

DoRA decomposes each weight update into two independent components:

```
W' = m · (W₀ + B·A) / ‖W₀ + B·A‖₂
```

| Component | Symbol | What it learns |
|-----------|--------|----------------|
| Low-rank matrices | A, B | **Direction** of weight change (same as LoRA) |
| Magnitude vector | m | **Scale** of each output column (new in DoRA) |

By decoupling magnitude from direction, DoRA matches full fine-tuning behaviour more
closely than LoRA, while using the same number of trainable direction parameters
plus one small magnitude vector per adapted layer.

**In practice:** DoRA at rank 32 ≈ LoRA at rank 64–128 in quality, using half the adapter parameters.

---

## Project structure

```
dreambooth-dora/
├── app.py               ← FastAPI server (UI + REST API)
├── inference.py         ← Inference pipeline (loads DoRA checkpoint)
├── training/
│   └── train.py         ← Full DreamBooth + DoRA training loop
├── templates/
│   └── index.html       ← Web UI (single-page app)
├── static/              ← CSS / JS assets (if any)
├── uploads/             ← Training images (auto-created)
├── checkpoints/         ← Saved DoRA adapters (auto-created)
├── outputs/             ← Generated images (auto-created)
├── requirements.txt
├── run.sh               ← Linux / macOS launcher
└── run.bat              ← Windows launcher
```

---

## Quick start

### Linux / macOS

```bash
# 1. Clone or unzip the project
cd dreambooth-dora

# 2. Install + launch (creates a virtualenv automatically)
bash run.sh

# 3. Open your browser
open http://localhost:8000
```

### Windows

Double-click `run.bat` — it will install everything and open the browser automatically.

### Manual install

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# Install PyTorch first (match your CUDA version)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

pip install -r requirements.txt
python app.py
```

---

## Hardware requirements

| Setup | Minimum | Recommended |
|-------|---------|-------------|
| GPU VRAM (SD 1.5) | 6 GB | 8 GB |
| GPU VRAM (SDXL)   | 12 GB | 16 GB |
| RAM | 16 GB | 32 GB |
| Disk (model cache) | 20 GB | 40 GB |

**No GPU?** The server runs in simulation mode — the UI and training progress are fully
functional, but no real images are generated. Useful for testing the workflow.

---

## Training workflow

1. **Upload images** — 5–20 photos of your subject (min 512×512 px recommended).
   Varied angles, lighting, and backgrounds improve results.

2. **Set subject config:**
   - **Unique token** — a rare identifier like `[V]` or `sks` that the model will
     associate with your subject
   - **Class word** — the category (e.g. `person`, `dog`, `car`)
   - **Instance prompt** — `a photo of [V] person`
   - **Class prompt** — `a photo of a person` (for prior preservation)

3. **Configure DoRA:**
   - **Rank r** — higher = more capacity but more VRAM (32 is a good default)
   - **Alpha α** — scaling factor; effective scale = α/r (keep equal to r to start)
   - **Target modules** — which attention projections to adapt

4. **Start training** — watch the live progress and loss log in the UI.

5. **Generate** — switch to the Generate tab, select your trained job, and start creating images.

---

## Inference — using your checkpoint

```python
from inference import run_inference

images = run_inference({
    "prompt": "a photo of [V] person on the moon, dramatic lighting",
    "negative_prompt": "blurry, low quality",
    "job_id": "abc12345",   # your job ID from the UI
    "steps": 30,
    "guidance_scale": 7.5,
    "width": 768,
    "height": 768,
    "num_images": 4,
    "seed": 42,
})
# images is a list of base64 PNG data-URIs
```

---

## Training from the command line

```bash
python training/train.py \
  --session_id=mysession \
  --instance_prompt="a photo of [V] person" \
  --class_prompt="a photo of a person" \
  --model_base="runwayml/stable-diffusion-v1-5" \
  --max_train_steps=1000 \
  --learning_rate=2e-6 \
  --dora_rank=32 \
  --dora_alpha=32 \
  --dora_target_modules="q,k,v,out" \
  --output_dir=checkpoints/myrun \
  --with_prior_preservation
```

---

## API reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/train/upload` | Upload training images |
| POST | `/api/train/start` | Start a training job |
| GET | `/api/train/status/{job_id}` | Poll job status + logs |
| GET | `/api/train/jobs` | List all jobs |
| POST | `/api/generate` | Generate images |

---

## Tips for best results

- **Image diversity** — vary the background, lighting angle, and expression.
  Avoid near-duplicate photos.
- **Steps** — 800–1200 steps for ~5 images; 1500–2000 for 15–20 images.
- **DoRA rank** — r=32 is the sweet spot. Go higher only if the subject has
  very fine-grained texture (e.g., intricate patterns).
- **CFG scale** — 7–9 for photorealism, lower for artistic styles.
- **Include the token** — always put `[V]` (or your chosen token) in the prompt
  when generating. Without it, DoRA weights are ignored.

---

## Credits

- [DreamBooth](https://dreambooth.github.io/) — Ruiz et al., Google Research (2022)
- [DoRA](https://arxiv.org/abs/2402.09353) — Liu et al. (2024)
- [PEFT](https://github.com/huggingface/peft) — Hugging Face (DoRA via `use_dora=True`)
- [Diffusers](https://github.com/huggingface/diffusers) — Hugging Face
