@echo off
REM ─────────────────────────────────────────────────────────
REM  DreamBooth + DoRA Studio — Windows launcher
REM  Usage: Double-click run.bat  OR  run it from cmd
REM ─────────────────────────────────────────────────────────
title DreamBooth + DoRA Studio

echo.
echo   DREAM + DORA Studio
echo   DreamBooth + Weight-Decomposed Adaptation
echo.

REM ── Check Python ──────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found.
    echo Install Python 3.10+ from https://python.org and retry.
    pause
    exit /b 1
)

REM ── Create virtualenv if needed ───────────────────────────
if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

REM ── Install dependencies ──────────────────────────────────
echo Installing dependencies...
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo Dependencies installed.

REM ── Create dirs ───────────────────────────────────────────
if not exist "uploads" mkdir uploads
if not exist "outputs" mkdir outputs
if not exist "checkpoints" mkdir checkpoints

REM ── Launch ────────────────────────────────────────────────
echo.
echo   Starting server at http://localhost:8000
echo   Open your browser to http://localhost:8000
echo   Press Ctrl+C to stop
echo.
start "" http://localhost:8000
python app.py

pause
