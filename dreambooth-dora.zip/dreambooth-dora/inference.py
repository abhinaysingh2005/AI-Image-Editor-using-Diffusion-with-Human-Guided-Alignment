"""
inference.py
────────────
Loads a trained DreamBooth + DoRA checkpoint and generates images.
Called by app.py's /api/generate endpoint.
"""

import base64, io, json, logging
from pathlib import Path
from typing import Optional

import torch
from diffusers import StableDiffusionPipeline, DPMSolverMultistepScheduler
from peft import PeftModel

log = logging.getLogger(__name__)

# Global pipeline cache  {job_id: pipeline}
_pipeline_cache: dict[str, StableDiffusionPipeline] = {}


def _load_pipeline(job_id: Optional[str], model_base: str) -> StableDiffusionPipeline:
    cache_key = job_id or "base"

    if cache_key in _pipeline_cache:
        return _pipeline_cache[cache_key]

    log.info(f"Loading pipeline — base: {model_base} | checkpoint: {job_id or 'none'}")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype  = torch.float16 if device == "cuda" else torch.float32

    pipe = StableDiffusionPipeline.from_pretrained(
        model_base,
        torch_dtype=dtype,
        safety_checker=None,
        requires_safety_checker=False,
    ).to(device)

    # Load DoRA weights if a checkpoint exists
    if job_id:
        ckpt_path = Path("checkpoints") / job_id / "unet_dora"
        if ckpt_path.exists():
            log.info(f"Loading DoRA weights from {ckpt_path}")
            pipe.unet = PeftModel.from_pretrained(pipe.unet, str(ckpt_path))
            log.info("DoRA weights loaded ✓")
        else:
            log.warning(f"Checkpoint not found at {ckpt_path}, using base model")

    # Fast scheduler
    pipe.scheduler = DPMSolverMultistepScheduler.from_config(
        pipe.scheduler.config,
        use_karras_sigmas=True,
    )
    pipe.enable_attention_slicing()

    _pipeline_cache[cache_key] = pipe
    return pipe


def run_inference(params: dict) -> list[str]:
    """
    Generate images and return a list of base64-encoded PNG data-URIs.
    """
    job_id   = params.get("job_id")
    model_base = "runwayml/stable-diffusion-v1-5"

    # Read config from checkpoint if available
    if job_id:
        cfg_path = Path("checkpoints") / job_id / "training_config.json"
        if cfg_path.exists():
            with open(cfg_path) as f:
                cfg = json.load(f)
            model_base = cfg.get("model_base", model_base)

    pipe = _load_pipeline(job_id, model_base)

    generator = torch.Generator(pipe.device).manual_seed(params["seed"])

    result = pipe(
        prompt              = params["prompt"],
        negative_prompt     = params.get("negative_prompt", ""),
        num_inference_steps = params.get("steps", 30),
        guidance_scale      = params.get("guidance_scale", 7.0),
        width               = params.get("width", 768),
        height              = params.get("height", 768),
        num_images_per_prompt = params.get("num_images", 2),
        generator           = generator,
    )

    images_b64 = []
    for img in result.images:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        images_b64.append(
            "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
        )

    return images_b64


def clear_cache(job_id: Optional[str] = None):
    """Free a cached pipeline to reclaim VRAM."""
    global _pipeline_cache
    if job_id and job_id in _pipeline_cache:
        del _pipeline_cache[job_id]
    elif job_id is None:
        _pipeline_cache.clear()
    torch.cuda.empty_cache()
